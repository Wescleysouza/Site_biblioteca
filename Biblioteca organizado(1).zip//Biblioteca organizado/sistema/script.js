// Objeto com os links para cada termo pesquisado//
var links = {
  "cachorro": "https://pt.m.wikipedia.org/wiki/C%C3%A3o",
  "gato": "https://exemplo.com/gato",
  "passarinho": "https://exemplo.com/passarinho",
  // adicione mais termos e links conforme necessário//
};

document.getElementById('searchForm').addEventListener('submit', function(event) {
  event.preventDefault();
  var searchTerm = document.getElementById('searchInput').value.toLowerCase();
  var searchUrl = links[searchTerm];
  
  if (searchUrl) {
    window.location.href = searchUrl;
  } else {
    document.getElementById('searchResults').textContent = "Nenhum resultado encontrado para: " + searchTerm;
  }
});

//transição de imagem//
