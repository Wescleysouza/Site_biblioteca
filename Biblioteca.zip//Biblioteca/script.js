$('.txt').html(function(i, html) {
  var chars = $.trim(html).split("");

  return '<h3>' + chars.join('</h3><h3>') + '</h3>';
});